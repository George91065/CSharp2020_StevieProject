﻿Things to do
Step 1->Go to Tools..NuGet Package Manager

Step 1a->Search for Dapper version 2.0.35 and install the first package with the latest version

Step 2-> Add a new class called customer with the following notes and public properties
        //Note the class has to follow the physical table schema in terms of the column names.
        //Otherwise the Dapper mapping will not work
        public int Customer_ID { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Email { get; set; }

Step 3-> Create a new database in SQL Server local db either through VS 2019 or SSMS
         Database name: Customers
         Table name: customer
         Fields: Customer_ID int Do not Allow Nulls and Identity
                 First_Name varchar(20) Allow Nulls
                 Last_Name varchar(20) Allow Nulls
                 Email varchar(40) Allow Nulls
Step 4->Add a using statement for the Dapper dll in the form where you want to use it in your code

Step 5->You can also customize the DataGridView. The datagridview selectionmode property
        is selected for FullRowSelect. Perform a Google search on the datagridview
        https://docs.microsoft.com/en-us/dotnet/desktop/winforms/controls/how-to-set-the-selection-mode-of-the-windows-forms-datagridview-control?view=netframeworkdesktop-4.8
