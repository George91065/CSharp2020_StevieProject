﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace DapperORMDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSelectAllRecords_Click(object sender, EventArgs e)
        {
           
                
        }

        private void btnInsertRecord_Click(object sender, EventArgs e)
        {
            
            
        }

        private void btnUpdateRecord_Click(object sender, EventArgs e)
        {
            
        }

        private void btnDeleteRecord_Click(object sender, EventArgs e)
        {
           
        }

        private void btnSelectSpecificRecord_Click(object sender, EventArgs e)
        {
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCustomerID.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtEmailAddress.Text = "";
            dataGridView1.DataSource = null;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
