﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dapper; //After adding the Dapper nuget package you must now reference the Dapper namespace


namespace DapperORMDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSelectAllRecords_Click(object sender, EventArgs e)
        {
            //Step 0- Add the Dapper namespace reference at the top in the using namespace section above
            //Step 1- Create our SQL statement
            //Step 2 - Create our database connection string
            //Step 3 - Call the Dapper Query method to execute the SQL and return the
            //         results as a Customer object
            //Step 4 -Display the results into the data grid
            //Replace the AttachdbFilename path with your own local SQL Server instance path in the connection string 

            string sqlString = "select * from customers";
            //Replace the AttachdbFilename path with your own local SQL Server instance path in the connection string 
            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;AttachDbFilename=c:\users\Stevie\Customers.mdf;Integrated Security=True;Connect Timeout=30";

            try
            {
                using (IDbConnection db = new SqlConnection(connectionString))
                {
                    List<Customer> myCustomerList = new List<Customer>();

                    myCustomerList = db.Query<Customer>(sqlString).ToList();
                    dataGridView1.DataSource = myCustomerList;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
                
        }

        private void btnInsertRecord_Click(object sender, EventArgs e)
        {
            try
            {
                int rowsAffected = 0;
                string sqlString = "insert into customers values (@firstname, @lastname, @email)";
                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;AttachDbFilename=c:\users\Stevie\Customers.mdf;Integrated Security=True;Connect Timeout=30";

                using (IDbConnection db = new SqlConnection(connectionString))
                {
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@firstname", txtFirstName.Text.Trim(), DbType.String, ParameterDirection.Input);
                    parameters.Add("@lastname", txtLastName.Text.Trim(), DbType.String, ParameterDirection.Input);
                    parameters.Add("@email", txtEmailAddress.Text.Trim(), DbType.String, ParameterDirection.Input);

                    rowsAffected = db.Execute(sqlString, parameters);
                    MessageBox.Show($"{rowsAffected} record has been inserted.");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }


        }

        private void btnUpdateRecord_Click(object sender, EventArgs e)
        {
            try
            {
                int rowsAffected = 0;
                string sqlString = "update customers " +
                         " set first_name = @firstname, " +
                         "     last_name =  @lastname, " +
                         "     email = @email " +
                         "where customer_id = @customerID";

                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;AttachDbFilename=c:\users\Stevie\Customers.mdf;Integrated Security=True;Connect Timeout=30";

                using (IDbConnection db = new SqlConnection(connectionString))
                {
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@firstname", txtFirstName.Text.Trim(), DbType.String, ParameterDirection.Input);
                    parameters.Add("@lastname", txtLastName.Text.Trim(), DbType.String, ParameterDirection.Input);
                    parameters.Add("@email", txtEmailAddress.Text.Trim(), DbType.String, ParameterDirection.Input);
                    parameters.Add("@customerID", txtCustomerID.Text.Trim(), DbType.String, ParameterDirection.Input);

                    rowsAffected = db.Execute(sqlString, parameters);
                    MessageBox.Show($"{rowsAffected} record has been updated.");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        private void btnDeleteRecord_Click(object sender, EventArgs e)
        {
            try
            {
                int rowsAffected = 0;
                string sqlString = "delete customers where customer_id = @customerID";
                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;AttachDbFilename=c:\users\Stevie\Customers.mdf;Integrated Security=True;Connect Timeout=30";

                using (IDbConnection db = new SqlConnection(connectionString))
                {
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@customerID", txtCustomerID.Text.Trim(), DbType.String, ParameterDirection.Input);
                   
                    rowsAffected = db.Execute(sqlString, parameters);
                    MessageBox.Show($"{rowsAffected} record has been deleted.");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        private void btnSelectSpecificRecord_Click(object sender, EventArgs e)
        {
            string sqlString = "select * from customers where customer_id = @customerID";
            //Replace the AttachdbFilename path with your own local SQL Server instance path in the connection string 
            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;AttachDbFilename=c:\users\Stevie\Customers.mdf;Integrated Security=True;Connect Timeout=30";

            try
            {
                using (IDbConnection db = new SqlConnection(connectionString))
                {
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@customerID", txtCustomerID.Text.Trim(), DbType.String, ParameterDirection.Input);
                    
                    Customer mycustomer = db.QueryFirstOrDefault<Customer>(sqlString, parameters);
                    if (mycustomer is null)
                    {
                        MessageBox.Show($"Customer id {txtCustomerID.Text.Trim()} not found in the database.");
                        return;
                    }

                    //Populate the UI with the returned customer info
                    txtCustomerID.Text = mycustomer.Customer_ID.ToString();
                    txtCustomerID.ReadOnly = true;
                    txtFirstName.Text = mycustomer.First_Name;
                    txtLastName.Text = mycustomer.Last_Name;
                    txtEmailAddress.Text = mycustomer.Email;

                    //Populate the grid
                    List<Customer> myCustomerList = new List<Customer>()
                    {
                        new Customer() { Customer_ID=Convert.ToInt32(txtCustomerID.Text), 
                                         First_Name = txtFirstName.Text,
                                         Last_Name = txtLastName.Text,
                                         Email = txtEmailAddress.Text}                         
                    };

                    dataGridView1.DataSource = myCustomerList;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count >0)
            {
                txtCustomerID.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                txtFirstName.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                txtLastName.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                txtEmailAddress.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();

            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCustomerID.Text = "";
            txtCustomerID.ReadOnly = false;
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtEmailAddress.Text = "";
            dataGridView1.DataSource = null;
        }
    }
}
